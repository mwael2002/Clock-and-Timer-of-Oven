/*
 * Keypad_private.h
 *
 *  Created on: Sep 18, 2021
 *      Author: mwael
 */

#ifndef KEYPAD_PRIVATE_H_
#define KEYPAD_PRIVATE_H_
#define Row_no 4
#define Column_no 4


#endif /* KEYPAD_PRIVATE_H_ */
