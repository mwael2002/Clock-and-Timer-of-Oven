/*
 * Keybad_interface.h
 *
 *  Created on: Sep 18, 2021
 *      Author: mwael
 */

#ifndef KEYPAD_INTERFACE_H_
#define KEYPAD_INTERFACE_H_


U8 KPD_status(void);
void KPD_init(void);

#define No_pressed_key 255
#endif /* KEYPAD_INTERFACE_H_ */
