/*
 * Buzzer_interface.h
 *
 *  Created on: Sep 9, 2022
 *      Author: mwael
 */

#ifndef BUZZER_INTERFACE_H_
#define BUZZER_INTERFACE_H_



void Buzzer_init(void);
void Buzzer_On(void);
void Buzzer_Off(void);

#endif /* BUZZER_INTERFACE_H_ */
