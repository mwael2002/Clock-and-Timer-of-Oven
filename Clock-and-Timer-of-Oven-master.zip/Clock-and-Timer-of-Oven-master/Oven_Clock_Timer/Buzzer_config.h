/*
 * Buzzer_config.h
 *
 *  Created on: Sep 9, 2022
 *      Author: mwael
 */

#ifndef BUZZER_CONFIG_H_
#define BUZZER_CONFIG_H_

#define BUZZER_PORT    		Group_C
#define BUZZER_PIN			DIO_Pin_7

#endif /* BUZZER_CONFIG_H_ */
